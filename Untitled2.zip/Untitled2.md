

```python
from numpy import genfromtxt, zeros
data = genfromtxt('iris.csv',delimiter=',',usecols=(0,1,2,3))
# read the fifth column
target = genfromtxt('iris.csv',delimiter=',',usecols=(4),dtype=str)
print (data.shape)
print (target.shape)
print (set (target))
```

    (150, 4)
    (150,)
    {'setosa', 'versicolor', 'virginica'}
    


```python
from pylab import plot, show
plot(data[target=='setosa',0],data[target=='setosa',2],'bo')
plot(data[target=='versicolor',0],data[target=='versicolor',2],'ro')
plot(data[target=='virginica',0],data[target=='virginica',2],'go')
show()
```


![png](output_1_0.png)



```python
t = zeros(len(target))
t[target == 'setosa'] = 1
t[target == 'versicolor'] = 2
t[target == 'virginica'] = 3
```


```python
from sklearn.neighbors.nearest_centroid import NearestCentroid
classifier = NearestCentroid()
classifier.fit(data,t)
```




    NearestCentroid(metric='euclidean', shrink_threshold=None)




```python
print (classifier.predict(data[0]))
```

    [ 1.]
    

    C:\Users\USER\Anaconda3\lib\site-packages\sklearn\utils\validation.py:395: DeprecationWarning: Passing 1d arrays as data is deprecated in 0.17 and will raise ValueError in 0.19. Reshape your data either using X.reshape(-1, 1) if your data has a single feature or X.reshape(1, -1) if it contains a single sample.
      DeprecationWarning)
    


```python
print (t[0])
```

    1.0
    


```python
from sklearn import cross_validation
train, test, t_train, t_test = cross_validation.train_test_split(data, t
, test_size=0.4, random_state=0)
```

    C:\Users\USER\Anaconda3\lib\site-packages\sklearn\cross_validation.py:44: DeprecationWarning: This module was deprecated in version 0.18 in favor of the model_selection module into which all the refactored classes and functions are moved. Also note that the interface of the new CV iterators are different from that of this module. This module will be removed in 0.20.
      "This module will be removed in 0.20.", DeprecationWarning)
    


```python
classifier.fit(train,t_train) 
print (classifier.score(test,t_test))
```

    0.866666666667
    


```python
from sklearn.metrics import confusion_matrix
print (confusion_matrix(classifier.predict(test),t_test))
```

    [[16  0  0]
     [ 0 22  7]
     [ 0  1 14]]
    


```python

```
